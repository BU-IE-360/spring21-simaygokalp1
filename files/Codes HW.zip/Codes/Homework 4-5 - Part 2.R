source("Functions.r")
library(data.table)
library(ggplot2)
library(skimr)
library(ggcorrplot)
library(GGally)
library(forecast)
library(lubridate)
library(urca)

raw_data <- read.csv("ProjectRawData.csv")

##### Xiaomi ----
xiaomi <- ArrangeTestData(6676673)
xiaomi <- xiaomi[event_date < ymd("2021-06-24")]

# Daily Seasonality
xiaomi_ts_week <- ts(xiaomi$sold_count, frequency = 7)
tsdisplay((xiaomi_ts_week))
acf(xiaomi$sold_count, lag.max = 50)
xiaomi_ts_week_dec <- decompose(xiaomi_ts_week, type = "additive")
plot(xiaomi_ts_week_dec)
summary(ur.kpss(xiaomi_ts_week_dec$random))

# Annual Seasonality
xiaomi_ts_year <- ts(xiaomi$sold_count, frequency = 32)
tsdisplay((xiaomi_ts_year))
acf(xiaomi$sold_count, lag.max = 50)
xiaomi_ts_year_dec <- decompose(xiaomi_ts_year, type = "additive")
plot(xiaomi_ts_year_dec)
summary(ur.kpss(xiaomi_ts_year_dec$random))

# Arima Model
xiaomi_random <- xiaomi_ts_week_dec$random
acf(xiaomi_random, na.action = na.pass, lag.max = 50)
pacf(xiaomi_random, na.action = na.pass, lag.max = 50)

m1 <- arima(xiaomi_random, c(0,0,3))
m3 <- arima(xiaomi_random, c(2,0,4))
AIC(m1)
AIC(m3)

xiaomi[, Model1 := as.numeric(xiaomi_ts_week_dec$seasonal)+as.numeric(xiaomi_ts_week_dec$trend)+as.numeric(fitted(m3))]
checkresiduals(m3)
ggplot(xiaomi, aes(x = event_date))+
  geom_line(aes(y = Model1), color = 'red')+
  geom_line(aes(y = sold_count), color = 'black')

ggplot(xiaomi, aes(x = sold_count))+
  geom_point(aes(y = sold_count - Model1))+
  geom_abline(slope = 1, intercept = 0)

acf(xiaomi$sold_count-xiaomi$Model1, na.action = na.pass)

# Additional Regressors
plot(xiaomi$price) # ok
plot(xiaomi$visit_count) 
plot(xiaomi$basket_count) # ok
plot(xiaomi$favored_count)
plot(xiaomi$category_sold) # not ok unusual behavior
plot(xiaomi$category_basket)
plot(xiaomi$category_visits)
plot(xiaomi$category_favored) # ok
plot(xiaomi$category_brand_sold)

xiaomi[,price_lag1 := shift(price,1)]
xiaomi[,basket_count_lag2 := shift(basket_count,2)]
xiaomi[,category_favored_lag2 := shift(category_favored,2)]
ggpairs(xiaomi[,c(4,18:20)])

# New Model - use price lag 1 + basket count lag 1
#m2 <- auto.arima(xiaomi_random, xreg = matrix(c(xiaomi$price_lag1, xiaomi$basket_count_lag1), byrow = FALSE, ncol = 2), trace = TRUE)
m2 <- arima(xiaomi_random, c(3,0,2), xreg = matrix(c(xiaomi$price_lag1, xiaomi$basket_count_lag2), byrow = FALSE, ncol = 2))
AIC(m2)
summary(m2)
checkresiduals(m2)

xiaomi[, Model2 := as.numeric(xiaomi_ts_week_dec$seasonal)+as.numeric(xiaomi_ts_week_dec$trend)+as.numeric(fitted(m2))]

ggplot(xiaomi, aes(x = event_date))+
  geom_line(aes(y = Model2), color = 'red')+
  geom_line(aes(y = sold_count), color = 'black')

ggplot(xiaomi, aes(x = sold_count))+
  geom_point(aes(y = sold_count - Model1))

acf(xiaomi$sold_count-xiaomi$Model1, na.action = na.pass)

# Testing

xiaomi_test <- ArrangeTestData(6676673)
xiaomi_test <- xiaomi_test[event_date <= ymd("2021-06-30")]
xiaomi_test[,price_lag1 := shift(price,1)]
xiaomi_test[,basket_count_lag2 := shift(basket_count,2)]
test_dates=seq(ydm("2021-24-06"),ydm("2021-30-06"),by='day')

for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- xiaomi_test[event_date<=current_date,]
  series <- ts(past_data$sold_count, frequency = 7)
  dec <- decompose(series,type = "additive")
  model <- arima(dec$random,order = c(2,0,4))
  forecasted=predict(model,n.ahead = 2)
  xiaomi_test[nrow(xiaomi_test)-length(test_dates)+i,Model1:=forecasted$pred[2]+dec$seasonal[(nrow(xiaomi_test)-length(test_dates)+i)%%7+7]+xiaomi_test$trend[max(which(!is.na(xiaomi_test$trend)))]]
}

for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- xiaomi_test[event_date<=current_date,]
  series <- ts(past_data$sold_count, frequency = 7)
  dec <- decompose(series,type = "additive")
  model <- arima(dec$random,order = c(2,0,4), xreg = matrix(c(past_data$price_lag1, past_data$basket_count_lag2), byrow=FALSE, ncol = 2))
  forecasted=predict(model,n.ahead = 2, newxreg = xiaomi_test[event_date==test_dates[i],c("price_lag1","basket_count_lag2")])
  xiaomi_test[nrow(xiaomi_test)-length(test_dates)+i,Model2:=forecasted$pred[2]+dec$seasonal[(nrow(xiaomi_test)-length(test_dates)+i)%%7+7]+xiaomi_test$trend[max(which(!is.na(xiaomi_test$trend)))]]
}

xiaomi_perf <- tail(xiaomi_test,7)
model1 <- accu(xiaomi_perf$sold_count, xiaomi_perf$Model1)
model2 <- accu(xiaomi_perf$sold_count, xiaomi_perf$Model2)
frame_xiaomi <- data.frame(model1)
frame_xiaomi[2,] <- model2
frame_xiaomi

##### Fakir ----
fakir <- ArrangeTestData(7061886)
fakir <- fakir[event_date < ymd("2021-06-24")]

acf(fakir$sold_count, lag.max = 50)

# Daily Seasonality
fakir_ts_week <- ts(fakir$sold_count, frequency = 7)
tsdisplay((fakir_ts_week))

fakir_ts_week_dec <- decompose(fakir_ts_week, type = "additive")
plot(fakir_ts_week_dec)
summary(ur.kpss(fakir_ts_week_dec$random))

# Annual Seasonality
fakir_ts_year <- ts(fakir$sold_count, frequency = 16)
tsdisplay((fakir_ts_year))
fakir_ts_year_dec <- decompose(fakir_ts_year, type = "additive")
plot(fakir_ts_year_dec)
summary(ur.kpss(fakir_ts_year_dec$random))

# Arima Model

fakir_random <- fakir_ts_week_dec$random
acf(fakir_random, na.action = na.pass, lag.max = 40)
pacf(fakir_random, na.action = na.pass, lag.max = 40)
plot(fakir_random)

m1_fakir <- arima(fakir_random, c(0,0,4), include.mean = FALSE)
m3_fakir<- arima(fakir_random, c(2,0,4))
AIC(m1_fakir)

fakir[, Model1 := as.numeric(fakir_ts_week_dec$seasonal)+as.numeric(fakir_ts_week_dec$trend)+as.numeric(fitted(m1_fakir))]
checkresiduals(m1_fakir)
ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = Model1), color = 'red')+
  geom_line(aes(y = sold_count), color = 'black')

ggplot(fakir, aes(x = sold_count))+
  geom_point(aes(y = sold_count - Model1))

acf(fakir$sold_count-fakir$Model1, na.action = na.pass)

# Additional Regressors
plot(fakir$price) # ok
plot(fakir$visit_count) 
plot(fakir$basket_count) # ok
plot(fakir$favored_count)
plot(fakir$category_sold) # ok
plot(fakir$category_basket)
plot(fakir$category_visits)
plot(fakir$category_favored) # ok
plot(fakir$category_brand_sold)

fakir[,price_lag1 := shift(price,1)]
fakir[,basket_count_lag2 := shift(basket_count,2)]
fakir[,category_favored_lag2 := shift(category_favored,2)]
fakir[,category_sold_lag2 := shift(category_sold,2)]
ggpairs(fakir[,c(4,18:21)])

# New Model
#m2_fakir <- auto.arima(fakir_random, xreg = matrix(c(fakir$price_lag1, fakir$basket_count_lag1), byrow = FALSE, ncol = 2), trace = TRUE)
m2_fakir <- arima(fakir_random, c(3,0,1),include.mean = FALSE, xreg = matrix(c(fakir$price_lag1, fakir$basket_count_lag2, fakir$category_favored_lag2), byrow = FALSE, ncol = 3))
AIC(m2_fakir)
summary(m2_fakir)
checkresiduals(m2_fakir)

fakir[, Model2 := as.numeric(fakir_ts_week_dec$seasonal)+as.numeric(fakir_ts_week_dec$trend)+as.numeric(fitted(m2_fakir))]

ggplot(fakir, aes(x = event_date))+
  geom_line(aes(y = Model2), color = 'red')+
  geom_line(aes(y = sold_count), color = 'black')

ggplot(fakir, aes(x = sold_count))+
  geom_point(aes(y = sold_count - Model1))

acf(fakir$sold_count-fakir$Model1, na.action = na.pass)

# Testing
fakir_test <- ArrangeTestData(6676673)
fakir_test <- fakir_test[event_date <= ymd("2021-06-30")]
fakir_test[,price_lag1 := shift(price,1)]
fakir_test[,basket_count_lag2 := shift(basket_count,2)]
fakir_test[,category_favored_lag2 := shift(category_favored,2)]
test_dates=seq(ydm("2021-24-06"),ydm("2021-30-06"),by='day')

for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- fakir_test[event_date<=current_date,]
  series <- ts(past_data$sold_count, frequency = 7)
  dec <- decompose(series,type = "additive")
  model <- arima(dec$random,order = c(0,0,4))
  forecasted=predict(model,n.ahead = 2)
  fakir_test[nrow(fakir_test)-length(test_dates)+i,Model1:=forecasted$pred[2]+dec$seasonal[(nrow(fakir_test)-length(test_dates)+i)%%7+7]+fakir_test$trend[max(which(!is.na(fakir_test$trend)))]]
}

for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- fakir_test[event_date<=current_date,]
  series <- ts(past_data$sold_count, frequency = 7)
  dec <- decompose(series,type = "additive")
  model <- arima(dec$random,order = c(2,0,4), xreg = matrix(c(past_data$price_lag1, past_data$basket_count_lag2, past_data$category_favored_lag2), byrow=FALSE, ncol = 3))
  forecasted = predict(model,n.ahead = 2, newxreg = fakir_test[event_date==test_dates[i],c("price_lag1","basket_count_lag2", "category_favored_lag2")])
  fakir_test[nrow(fakir_test)-length(test_dates)+i,Model2:=forecasted$pred[2]+dec$seasonal[(nrow(fakir_test)-length(test_dates)+i)%%7+7]+fakir_test$trend[max(which(!is.na(fakir_test$trend)))]]
}

fakir_perf <- tail(fakir_test,7)
model1 <- accu(fakir_perf$sold_count, fakir_perf$Model1)
model2 <- accu(fakir_perf$sold_count, fakir_perf$Model2)
frame_fakir <- data.frame(model1)
frame_fakir[2,] <- model2
frame_fakir

##### Altinyildiz  ----
mont <- ArrangeTestData(48740784)
mont <- mont[event_date < ymd("2021-06-24")]

acf(mont$sold_count, lag.max = 50)
pacf(mont$sold_count, lag.max = 50)

# Daily Seasonality
mont_ts_week <- ts(mont$sold_count, frequency = 7)
tsdisplay((mont_ts_week))

mont_ts_week_dec <- decompose(mont_ts_week, type = "additive")
plot(mont_ts_week_dec)
summary(ur.kpss(mont_ts_week_dec$random))

# Decompositio with frequency = 20
mont_ts_year <- ts(mont$sold_count, frequency = 20)
tsdisplay((mont_ts_year))
acf(mont$sold_count, lag.max = 50)
mont_ts_year_dec <- decompose(mont_ts_year, type = "additive")
plot(mont_ts_year_dec)
summary(ur.kpss(mont_ts_year_dec$random))

# Arima Model
mont_random <- mont_ts_week_dec$random
acf(mont_random, na.action = na.pass, lag.max = 40)
pacf(mont_random, na.action = na.pass, lag.max = 40)
plot(mont_random)

m1_mont <- arima(mont_random, c(0,0,5), include.mean = FALSE)
AIC(m1_mont)

mont[, Model1 := as.numeric(mont_ts_week_dec$seasonal)+as.numeric(mont_ts_week_dec$trend)+as.numeric(fitted(m1_fakir))]
checkresiduals(m1_mont)
ggplot(mont, aes(x = event_date))+
  geom_line(aes(y = Model1), color = 'red')+
  geom_line(aes(y = sold_count), color = 'black')

ggplot(mont, aes(x = sold_count))+
  geom_point(aes(y = sold_count - Model1))

acf(mont$sold_count-mont$Model1, na.action = na.pass)

# Additional Regressors
plot(mont$price)
plot(mont$sold_count)
plot(mont$visit_count) 
plot(mont$basket_count) # ok
plot(mont$favored_count) # ok
plot(mont$category_sold) # ok
plot(mont$category_basket) # not ok
plot(mont$category_visits) # not ok
plot(mont$category_favored) # ok
plot(mont$category_brand_sold)# not ok

mont[,favored_count_lag2 := shift(favored_count,2)]
mont[,basket_count_lag2 := shift(basket_count,2)]
mont[,category_favored_lag2 := shift(category_favored,2)]
mont[,category_sold_lag2 := shift(category_sold,2)]
ggpairs(mont[,c(4,18:21)])

# New Model
#m2_mont <- auto.arima(mont_random, xreg = matrix(c(mont$basket_count_lag1), byrow = FALSE, ncol = 1), trace = TRUE)
m2_mont <- arima(mont_random, c(3,0,2), xreg = matrix(c(mont$basket_count_lag2), byrow = FALSE, ncol = 1))
AIC(m2_mont)
summary(m2_mont)
checkresiduals(m2_mont)

mont[, Model2 := as.numeric(mont_ts_week_dec$seasonal)+as.numeric(mont_ts_week_dec$trend)+as.numeric(fitted(m2_mont))]

ggplot(mont, aes(x = event_date))+
  geom_line(aes(y = Model2), color = 'red')+
  geom_line(aes(y = sold_count), color = 'black')

ggplot(mont, aes(x = sold_count))+
  geom_point(aes(y = sold_count - Model1))

acf(mont$sold_count-mont$Model1, na.action = na.pass)

# Testing
mont_test <- ArrangeTestData(6676673)
mont_test <- mont_test[event_date <= ymd("2021-06-30")]
mont_test[,price_lag1 := shift(price,1)]
mont_test[,basket_count_lag2 := shift(basket_count,2)]
mont_test[,category_favored_lag2 := shift(category_favored,2)]
test_dates=seq(ydm("2021-24-06"),ydm("2021-30-06"),by='day')

for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- mont_test[event_date<=current_date,]
  series <- ts(past_data$sold_count, frequency = 7)
  dec <- decompose(series,type = "additive")
  model <- arima(dec$random,order = c(0,0,5))
  forecasted=predict(model,n.ahead = 2)
  mont_test[nrow(mont_test)-length(test_dates)+i,Model1:=forecasted$pred[2]+dec$seasonal[(nrow(mont_test)-length(test_dates)+i)%%7+7]+mont_test$trend[max(which(!is.na(mont_test$trend)))]]
}

for(i in 1:length(test_dates)){
  current_date=test_dates[i]-2
  past_data <- mont_test[event_date<=current_date,]
  series <- ts(past_data$sold_count, frequency = 7)
  dec <- decompose(series,type = "additive")
  model <- arima(dec$random,order = c(3,0,2), xreg = matrix(c(past_data$basket_count_lag2), byrow=FALSE, ncol = 1))
  forecasted = predict(model,n.ahead = 2, newxreg = mont_test[event_date==test_dates[i],c("basket_count_lag2")])
  mont_test[nrow(mont_test)-length(test_dates)+i,Model2:=forecasted$pred[2]+dec$seasonal[(nrow(mont_test)-length(test_dates)+i)%%7+7]+mont_test$trend[max(which(!is.na(mont_test$trend)))]]
}

mont_perf <- tail(mont_test,7)
model1 <- accu(mont_perf$sold_count, mont_perf$Model1)
model2 <- accu(mont_perf$sold_count, mont_perf$Model2)
frame_mont <- data.frame(model1)
frame_mont[2,] <- model2
frame_mont
