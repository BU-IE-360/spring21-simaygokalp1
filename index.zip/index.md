# Progress Journal

## HW0

[Here](files/GitHub.html) is the HW0 file.